'use strict';
/* ======================================================================
   منطق کسب‌وکار مشترک، سمت سرور — این‌جا «منبع حقیقت» است. برخلاف نسخه
   آفلاین قبلی که این قوانین در مرورگر اجرا می‌شدند (و با ابزار توسعه‌دهنده
   قابل دور زدن بودند)، این‌جا هیچ کاربری — صرف‌نظر از نقش — نمی‌تواند این
   قوانین را دور بزند، چون هر درخواست از این توابع عبور می‌کند.
   ====================================================================== */

const { db } = require('./db');

const DOC_PREFIXES = {
  in: 'IN', out: 'OUT', ret: 'RET', req: 'REQ',
  custIssue: 'CST', custReturn: 'CSR', repIn: 'REP', repOut: 'REPR'
};

function nextDocNumber(kind) {
  const row = db.prepare('SELECT value FROM counters WHERE kind = ?').get(kind);
  const next = (row ? row.value : 0) + 1;
  db.prepare('UPDATE counters SET value = ? WHERE kind = ?').run(next, kind);
  return `${DOC_PREFIXES[kind]}-${String(next).padStart(6, '0')}`;
}

// بعد از حذف یک سند، شماره‌های باقی‌مانده همان نوع را دوباره و پیوسته
// شماره‌گذاری می‌کند (طبق الزام صریح کارفرما: بدون شکاف در شماره اسناد)
function renumberTransactionsOfType(type) {
  const kindMap = { 'ورود': 'in', 'خروج': 'out', 'مرجوعی': 'ret' };
  const kind = kindMap[type];
  const prefix = DOC_PREFIXES[kind];
  const rows = db.prepare('SELECT id FROM transactions WHERE type = ? ORDER BY id ASC').all(type);
  const update = db.prepare('UPDATE transactions SET doc_number = ? WHERE id = ?');
  rows.forEach((row, idx) => {
    update.run(`${prefix}-${String(idx + 1).padStart(6, '0')}`, row.id);
  });
  db.prepare('UPDATE counters SET value = ? WHERE kind = ?').run(rows.length, kind);
}

function renumberRequests() {
  const rows = db.prepare('SELECT id FROM requests ORDER BY id ASC').all();
  const update = db.prepare('UPDATE requests SET doc_number = ? WHERE id = ?');
  rows.forEach((row, idx) => {
    update.run(`REQ-${String(idx + 1).padStart(6, '0')}`, row.id);
  });
  db.prepare("UPDATE counters SET value = ? WHERE kind = 'req'").run(rows.length);
}

function getStockStatus(product) {
  if (product.stock < product.min_stock) return 'critical';
  if (product.stock <= product.min_stock * 1.5) return 'warn';
  return 'ok';
}

function addAuditEntry({ action, docNumber, changeDescription, reason, userId }) {
  db.prepare(`INSERT INTO audit_log (timestamp, action, doc_number, change_description, reason, performed_by_user_id)
              VALUES (?, ?, ?, ?, ?, ?)`)
    .run(new Date().toISOString(), action, docNumber || null, changeDescription || null, reason || null, userId || null);
}

function isoToday() {
  return new Date().toISOString().split('T')[0];
}

module.exports = { nextDocNumber, renumberTransactionsOfType, renumberRequests, getStockStatus, addAuditEntry, isoToday, DOC_PREFIXES };
