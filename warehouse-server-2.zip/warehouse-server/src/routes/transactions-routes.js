'use strict';

const { db } = require('../db');
const { nextDocNumber, renumberTransactionsOfType, getStockStatus, addAuditEntry, isoToday } = require('../business');

const routes = [];

function serializeTransaction(row) {
  return {
    id: row.id, docNumber: row.doc_number, productId: row.product_id, type: row.type,
    quantity: row.quantity, date: row.date, source: row.source, poNumber: row.po_number,
    requestingUnit: row.requesting_unit, receiver: row.receiver, reason: row.reason,
    linkedRequestId: row.linked_request_id, returnedBy: row.returned_by, condition: row.condition_text,
    sourceDocId: row.source_doc_id, sourceDocNumber: row.source_doc_number, description: row.description,
    createdAt: row.created_at
  };
}

// ======================================================================
// رسید ورود
// ======================================================================
routes.push({
  method: 'POST', path: '/api/stock-in', permission: 'stock.in',
  handler: (ctx) => {
    const { productId, quantity, date, source, poNumber, linkedRequestId, description } = ctx.body || {};
    const qty = Number(quantity);
    if (!productId) return { status: 400, body: { error: 'انتخاب کالا الزامی است' } };
    if (isNaN(qty) || qty <= 0) return { status: 400, body: { error: 'تعداد باید عددی بزرگ‌تر از صفر باشد' } };
    if (!date) return { status: 400, body: { error: 'تاریخ الزامی است' } };

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(Number(productId));
    if (!product) return { status: 404, body: { error: 'کالای انتخاب‌شده معتبر نیست' } };

    const now = new Date().toISOString();
    const docNumber = nextDocNumber('in');

    db.prepare('UPDATE products SET stock = stock + ?, updated_at = ? WHERE id = ?').run(qty, now, product.id);
    const result = db.prepare(`INSERT INTO transactions (doc_number, product_id, type, quantity, date, source, po_number, linked_request_id, description, created_by_user_id, created_at)
                VALUES (?, ?, 'ورود', ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(docNumber, product.id, qty, date, source || null, poNumber || null, linkedRequestId || null, description || null, ctx.user.id, now);

    if (linkedRequestId) {
      db.prepare("UPDATE requests SET status = 'تأمین شده' WHERE id = ?").run(Number(linkedRequestId));
    }

    const tx = db.prepare('SELECT * FROM transactions WHERE id = ?').get(Number(result.lastInsertRowid));
    return { status: 201, body: { transaction: serializeTransaction(tx) } };
  }
});

// ======================================================================
// حواله خروج
// ======================================================================
routes.push({
  method: 'POST', path: '/api/stock-out', permission: 'stock.out',
  handler: (ctx) => {
    const { productId, quantity, date, requestingUnit, receiver, reason, description, force } = ctx.body || {};
    const qty = Number(quantity);
    if (!productId) return { status: 400, body: { error: 'انتخاب کالا الزامی است' } };
    if (isNaN(qty) || qty <= 0) return { status: 400, body: { error: 'تعداد باید عددی بزرگ‌تر از صفر باشد' } };
    if (!date) return { status: 400, body: { error: 'تاریخ الزامی است' } };
    if (!receiver || !String(receiver).trim()) return { status: 400, body: { error: 'نام تحویل‌گیرنده الزامی است' } };
    if (!requestingUnit) return { status: 400, body: { error: 'واحد درخواست‌کننده الزامی است' } };

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(Number(productId));
    if (!product) return { status: 404, body: { error: 'کالای انتخاب‌شده معتبر نیست' } };
    if (product.stock < qty) {
      return { status: 400, body: { error: `موجودی کافی نیست. موجودی فعلی «${product.name}»: ${product.stock} ${product.unit}` } };
    }
    if (product.type === 'قابل‌برگشت' && !force) {
      return {
        status: 409,
        body: {
          error: 'این کالا از نوع قابل‌برگشت (ابزار/تجهیز امانی) است. برای پیگیری بازگشت، از «امانت ابزار» استفاده کنید.',
          requiresForce: true
        }
      };
    }

    const now = new Date().toISOString();
    const docNumber = nextDocNumber('out');

    db.prepare('UPDATE products SET stock = stock - ?, updated_at = ? WHERE id = ?').run(qty, now, product.id);
    const result = db.prepare(`INSERT INTO transactions (doc_number, product_id, type, quantity, date, requesting_unit, receiver, reason, description, created_by_user_id, created_at)
                VALUES (?, ?, 'خروج', ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(docNumber, product.id, qty, date, requestingUnit, String(receiver).trim(), reason || null, description || null, ctx.user.id, now);

    const tx = db.prepare('SELECT * FROM transactions WHERE id = ?').get(Number(result.lastInsertRowid));
    return { status: 201, body: { transaction: serializeTransaction(tx) } };
  }
});

// ======================================================================
// مرجوعی
// ======================================================================
routes.push({
  method: 'POST', path: '/api/returns', permission: 'returns.create',
  handler: (ctx) => {
    const { productId, quantity, date, returnedBy, condition, reason, sourceDocId, description } = ctx.body || {};
    const qty = Number(quantity);
    if (!productId) return { status: 400, body: { error: 'انتخاب کالا الزامی است' } };
    if (isNaN(qty) || qty <= 0) return { status: 400, body: { error: 'تعداد باید عددی بزرگ‌تر از صفر باشد' } };
    if (!date) return { status: 400, body: { error: 'تاریخ الزامی است' } };
    if (!returnedBy || !String(returnedBy).trim()) return { status: 400, body: { error: 'نام تحویل‌دهنده الزامی است' } };

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(Number(productId));
    if (!product) return { status: 404, body: { error: 'کالای انتخاب‌شده معتبر نیست' } };

    let sourceDocNumber = null;
    if (sourceDocId) {
      const sourceDoc = db.prepare('SELECT * FROM transactions WHERE id = ?').get(Number(sourceDocId));
      if (sourceDoc) sourceDocNumber = sourceDoc.doc_number;
    }

    const now = new Date().toISOString();
    const docNumber = nextDocNumber('ret');

    db.prepare('UPDATE products SET stock = stock + ?, updated_at = ? WHERE id = ?').run(qty, now, product.id);
    const result = db.prepare(`INSERT INTO transactions (doc_number, product_id, type, quantity, date, returned_by, condition_text, reason, source_doc_id, source_doc_number, description, created_by_user_id, created_at)
                VALUES (?, ?, 'مرجوعی', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(docNumber, product.id, qty, date, String(returnedBy).trim(), condition || null, reason || null,
        sourceDocId || null, sourceDocNumber, description || null, ctx.user.id, now);

    const tx = db.prepare('SELECT * FROM transactions WHERE id = ?').get(Number(result.lastInsertRowid));
    return { status: 201, body: { transaction: serializeTransaction(tx) } };
  }
});

// ======================================================================
// فهرست اسناد (برای رسیدهای مرجع مرجوعی، تاریخچه، مدیریت اسناد)
// ======================================================================
routes.push({
  method: 'GET', path: '/api/transactions', permission: 'reports.view',
  handler: (ctx) => {
    const { type, productId, startDate, endDate, search } = ctx.query || {};
    let sql = 'SELECT * FROM transactions WHERE 1=1';
    const args = [];
    if (type) { sql += ' AND type = ?'; args.push(type); }
    if (productId) { sql += ' AND product_id = ?'; args.push(Number(productId)); }
    if (startDate) { sql += ' AND date >= ?'; args.push(startDate); }
    if (endDate) { sql += ' AND date <= ?'; args.push(endDate); }
    sql += ' ORDER BY id DESC';
    let rows = db.prepare(sql).all(...args);

    if (search) {
      const q = String(search).toLowerCase();
      const productsById = {};
      db.prepare('SELECT id, name, code FROM products').all().forEach(p => { productsById[p.id] = p; });
      rows = rows.filter(t => {
        const p = productsById[t.product_id];
        return (t.doc_number || '').toLowerCase().includes(q) ||
          (p && p.name.toLowerCase().includes(q)) || (p && p.code.toLowerCase().includes(q)) ||
          (t.source || '').toLowerCase().includes(q) || (t.receiver || '').toLowerCase().includes(q) ||
          (t.returned_by || '').toLowerCase().includes(q);
      });
    }

    return { status: 200, body: { transactions: rows.map(serializeTransaction) } };
  }
});

// ======================================================================
// مدیریت اسناد: ویرایش / حذف — فقط مدیر سیستم (permission انحصاری)
// ======================================================================
routes.push({
  method: 'PUT', path: '/api/documents/:id', permission: 'documents.manage',
  handler: (ctx) => {
    const id = Number(ctx.params.id);
    const t = db.prepare('SELECT * FROM transactions WHERE id = ?').get(id);
    if (!t) return { status: 404, body: { error: 'سند یافت نشد' } };

    const { quantity, date, party, description, reason } = ctx.body || {};
    if (!reason || !String(reason).trim()) return { status: 400, body: { error: 'ثبت دلیل ویرایش الزامی است' } };
    const newQty = Number(quantity);
    if (isNaN(newQty) || newQty <= 0) return { status: 400, body: { error: 'تعداد نامعتبر است' } };
    if (!date) return { status: 400, body: { error: 'تاریخ الزامی است' } };

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(t.product_id);
    const oldQty = t.quantity;
    const oldDate = t.date;
    const oldParty = t.type === 'ورود' ? (t.source || '') : t.type === 'مرجوعی' ? (t.returned_by || '') : (t.receiver || '');
    const oldDescription = t.description || '';

    if (product) {
      let newStock;
      if (t.type === 'ورود' || t.type === 'مرجوعی') {
        newStock = product.stock - oldQty + newQty;
      } else {
        newStock = product.stock + oldQty - newQty;
      }
      if (newStock < 0) {
        return { status: 400, body: { error: `این ویرایش باعث منفی شدن موجودی «${product.name}» می‌شود. عملیات لغو شد.` } };
      }
      db.prepare('UPDATE products SET stock = ?, updated_at = ? WHERE id = ?').run(newStock, new Date().toISOString(), product.id);
    }

    const partyColumn = t.type === 'ورود' ? 'source' : t.type === 'مرجوعی' ? 'returned_by' : 'receiver';
    db.prepare(`UPDATE transactions SET quantity = ?, date = ?, description = ?, ${partyColumn} = ? WHERE id = ?`)
      .run(newQty, date, description || null, party || null, id);

    const changeParts = [];
    if (oldQty !== newQty) changeParts.push(`تعداد: ${oldQty} ← ${newQty}`);
    if (oldDate !== date) changeParts.push(`تاریخ: ${oldDate} ← ${date}`);
    if (oldParty !== (party || '')) changeParts.push(`طرف حساب: «${oldParty || '-'}» ← «${party || '-'}»`);
    if (oldDescription !== (description || '')) changeParts.push('توضیحات تغییر یافت');
    const changeDescription = changeParts.length > 0 ? changeParts.join(' | ') : 'بدون تغییر در مقادیر';

    addAuditEntry({ action: 'ویرایش سند', docNumber: t.doc_number, changeDescription, reason: String(reason).trim(), userId: ctx.user.id });

    const updated = db.prepare('SELECT * FROM transactions WHERE id = ?').get(id);
    return { status: 200, body: { transaction: serializeTransaction(updated) } };
  }
});

routes.push({
  method: 'DELETE', path: '/api/documents/:id', permission: 'documents.manage',
  handler: (ctx) => {
    const id = Number(ctx.params.id);
    const t = db.prepare('SELECT * FROM transactions WHERE id = ?').get(id);
    if (!t) return { status: 404, body: { error: 'سند یافت نشد' } };

    const { reason } = ctx.body || {};
    if (!reason || !String(reason).trim()) return { status: 400, body: { error: 'ثبت دلیل حذف الزامی است' } };

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(t.product_id);
    if (product) {
      const newStock = (t.type === 'ورود' || t.type === 'مرجوعی')
        ? Math.max(0, product.stock - t.quantity)
        : product.stock + t.quantity;
      db.prepare('UPDATE products SET stock = ?, updated_at = ? WHERE id = ?').run(newStock, new Date().toISOString(), product.id);
    }

    const party = t.type === 'ورود' ? (t.source || '-') : t.type === 'مرجوعی' ? (t.returned_by || '-') : (t.receiver || '-');
    const changeDescription = `سند ${t.type} به تعداد ${t.quantity} ${product ? product.unit : ''} برای کالای «${product ? product.name : 'حذف‌شده'}» (طرف حساب: ${party}) حذف شد و موجودی اصلاح گردید.`;

    db.prepare('DELETE FROM transactions WHERE id = ?').run(id);
    renumberTransactionsOfType(t.type);

    addAuditEntry({ action: 'حذف سند', docNumber: t.doc_number, changeDescription, reason: String(reason).trim(), userId: ctx.user.id });

    return { status: 200, body: { ok: true } };
  }
});

module.exports = routes;
