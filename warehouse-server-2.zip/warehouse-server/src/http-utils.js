'use strict';
/* ======================================================================
   ابزارهای کمکی HTTP خام (بدون Express) — پارس بدنه JSON، کوکی، ارسال
   پاسخ، و سرو فایل استاتیک. برای نگه‌داشتن سرور بدون هیچ وابستگی خارجی.
   ====================================================================== */

const fs = require('node:fs');
const path = require('node:path');

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon'
};

function parseCookies(req) {
  const header = req.headers.cookie;
  const cookies = {};
  if (!header) return cookies;
  header.split(';').forEach(pair => {
    const idx = pair.indexOf('=');
    if (idx === -1) return;
    const key = pair.slice(0, idx).trim();
    const val = pair.slice(idx + 1).trim();
    cookies[key] = decodeURIComponent(val);
  });
  return cookies;
}

function readJsonBody(req, maxBytes = 2 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', chunk => {
      size += chunk.length;
      if (size > maxBytes) {
        reject(new Error('حجم درخواست بیش از حد مجاز است'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (chunks.length === 0) return resolve({});
      try {
        const raw = Buffer.concat(chunks).toString('utf8');
        resolve(raw ? JSON.parse(raw) : {});
      } catch (e) {
        reject(new Error('بدنه درخواست JSON معتبر نیست'));
      }
    });
    req.on('error', reject);
  });
}

function sendJson(res, statusCode, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body)
  });
  res.end(body);
}

function setSessionCookie(res, token, secure) {
  // httpOnly همیشه فعال است (جلوگیری از خواندن کوکی با جاوااسکریپت).
  // Secure فقط وقتی سرور روی HTTPS اجرا می‌شود اضافه می‌شود — روی HTTP
  // ساده (شبکه داخلی) مرورگرها اصلاً کوکی Secure را قبول نمی‌کنند.
  const secureFlag = secure ? '; Secure' : '';
  res.setHeader('Set-Cookie', `session=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=43200${secureFlag}`);
}

function clearSessionCookie(res) {
  res.setHeader('Set-Cookie', 'session=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0');
}

function getClientIp(req) {
  // برای یک استقرار ساده (بدون reverse proxy)، آدرس واقعی سوکت کافی است.
  return req.socket.remoteAddress || 'unknown';
}

function serveStatic(req, res, publicDir) {
  const normalizedRoot = path.resolve(publicDir);
  let urlPath = decodeURIComponent(req.url.split('?')[0]);
  if (urlPath === '/') urlPath = '/index.html';
  const filePath = path.normalize(path.join(normalizedRoot, urlPath));

  // prevent directory traversal outside publicDir
  if (!filePath.startsWith(normalizedRoot)) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('یافت نشد');
      return;
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

module.exports = { parseCookies, readJsonBody, sendJson, setSessionCookie, clearSessionCookie, serveStatic, getClientIp };
