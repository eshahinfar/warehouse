'use strict';
/* ======================================================================
   لایه‌های سخت‌سازی امنیتی — لازم برای زمانی که سرور روی اینترنت باز
   می‌شود (نه فقط شبکه داخلی کارخانه). این ماژول شامل سه دفاع مستقل است:

   ۱. محدودسازی تلاش ورود (ضدBrute-Force) — پنجره‌ی لغزان در حافظه، به
      ازای هر IP. این جایگزین فایروال/fail2ban سطح شبکه نیست، فقط یک
      لایه دفاعی اضافه در خود برنامه است.
   ۲. هدرهای امنیتی HTTP استاندارد (HSTS، CSP، ضدClickjacking، ...)
   ۳. بررسی Origin روی درخواست‌های تغییردهنده (POST/PUT/DELETE) — دفاع
      در برابر CSRF؛ چون کوکی نشست به‌صورت خودکار توسط مرورگر با هر
      درخواستی ارسال می‌شود، این بررسی مطمئن می‌شود درخواست واقعاً از
      خودِ سایت ما آمده، نه از یک صفحه مخرب دیگر.
   ====================================================================== */

const config = require('./config');

// ---------------------------------------------------------------------
// ۱. محدودسازی تلاش ورود
// ---------------------------------------------------------------------
const loginAttempts = new Map(); // ip -> { attempts: [timestamps], blockedUntil: number|null }

function getLoginState(ip) {
  let state = loginAttempts.get(ip);
  if (!state) {
    state = { attempts: [], blockedUntil: null };
    loginAttempts.set(ip, state);
  }
  return state;
}

function checkLoginRateLimit(ip) {
  const state = getLoginState(ip);
  const now = Date.now();

  if (state.blockedUntil && state.blockedUntil > now) {
    return { allowed: false, retryAfterSeconds: Math.ceil((state.blockedUntil - now) / 1000) };
  }
  if (state.blockedUntil && state.blockedUntil <= now) {
    state.blockedUntil = null;
    state.attempts = [];
  }

  state.attempts = state.attempts.filter(t => now - t < config.loginRateLimit.windowMs);
  if (state.attempts.length >= config.loginRateLimit.maxAttempts) {
    state.blockedUntil = now + config.loginRateLimit.blockMs;
    return { allowed: false, retryAfterSeconds: Math.ceil(config.loginRateLimit.blockMs / 1000) };
  }

  return { allowed: true };
}

function recordLoginFailure(ip) {
  const state = getLoginState(ip);
  state.attempts.push(Date.now());
}

function recordLoginSuccess(ip) {
  loginAttempts.delete(ip);
}

// پاک‌سازی دوره‌ای رکوردهای قدیمی (جلوگیری از رشد بی‌رویه حافظه)
function cleanupLoginAttempts() {
  const now = Date.now();
  for (const [ip, state] of loginAttempts.entries()) {
    const stillBlocked = state.blockedUntil && state.blockedUntil > now;
    const hasRecentAttempts = state.attempts.some(t => now - t < config.loginRateLimit.windowMs);
    if (!stillBlocked && !hasRecentAttempts) loginAttempts.delete(ip);
  }
}

// ---------------------------------------------------------------------
// ۲. هدرهای امنیتی
// ---------------------------------------------------------------------
function applySecurityHeaders(res, isHttps) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy',
    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self';");
  if (isHttps) {
    // به مرورگر می‌گوید برای یک سال فقط با HTTPS به این دامنه وصل شود
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }
}

// ---------------------------------------------------------------------
// ۳. بررسی Origin برای درخواست‌های تغییردهنده (دفاع CSRF)
// ---------------------------------------------------------------------
function buildAllowedOrigins() {
  const origins = new Set();
  origins.add(`http://localhost:${config.httpPort}`);
  origins.add(`http://127.0.0.1:${config.httpPort}`);
  if (config.mode === 'https' && config.domain) {
    origins.add(`https://${config.domain}`);
    if (config.httpsPort !== 443) origins.add(`https://${config.domain}:${config.httpsPort}`);
  }
  config.extraAllowedOrigins.forEach(o => origins.add(o));
  return origins;
}

const allowedOrigins = buildAllowedOrigins();

function isOriginAllowed(originHeader) {
  if (!originHeader) return true; // بسیاری کلاینت‌های غیرمرورگری (curl, ابزار داخلی) Origin نمی‌فرستند
  return allowedOrigins.has(originHeader);
}

module.exports = {
  checkLoginRateLimit,
  recordLoginFailure,
  recordLoginSuccess,
  cleanupLoginAttempts,
  applySecurityHeaders,
  isOriginAllowed,
  allowedOrigins
};
