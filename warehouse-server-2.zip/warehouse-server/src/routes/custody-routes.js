'use strict';

const { db } = require('../db');
const { nextDocNumber } = require('../business');

const routes = [];

function serializeCustody(row) {
  return {
    id: row.id, docNumber: row.doc_number, productId: row.product_id, quantity: row.quantity,
    issueDate: row.issue_date, holder: row.holder, unit: row.unit, expectedReturn: row.expected_return,
    conditionOut: row.condition_out, notes: row.notes, status: row.status,
    returnDate: row.return_date, conditionIn: row.condition_in, returnNotes: row.return_notes,
    returnDocNumber: row.return_doc_number
  };
}

function custodyOutstandingQty(productId) {
  const row = db.prepare("SELECT COALESCE(SUM(quantity),0) AS total FROM custody_records WHERE product_id = ? AND status = 'باز'").get(productId);
  return row.total;
}

routes.push({
  method: 'GET', path: '/api/custody', permission: 'custody.manage',
  handler: () => {
    const rows = db.prepare('SELECT * FROM custody_records ORDER BY id DESC').all();
    return { status: 200, body: { custodyRecords: rows.map(serializeCustody) } };
  }
});

routes.push({
  method: 'POST', path: '/api/custody/issue', permission: 'custody.manage',
  handler: (ctx) => {
    const { productId, quantity, date, holder, unit, expectedReturn, conditionOut, notes } = ctx.body || {};
    const qty = Number(quantity);
    if (!productId) return { status: 400, body: { error: 'انتخاب ابزار الزامی است' } };
    if (isNaN(qty) || qty <= 0) return { status: 400, body: { error: 'تعداد باید عددی بزرگ‌تر از صفر باشد' } };
    if (!date) return { status: 400, body: { error: 'تاریخ تحویل الزامی است' } };
    if (!holder || !String(holder).trim()) return { status: 400, body: { error: 'نام تحویل‌گیرنده الزامی است' } };
    if (!unit) return { status: 400, body: { error: 'واحد تحویل‌گیرنده الزامی است' } };

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(Number(productId));
    if (!product) return { status: 404, body: { error: 'ابزار انتخاب‌شده معتبر نیست' } };
    if (product.type !== 'قابل‌برگشت') return { status: 400, body: { error: 'این کالا از نوع قابل‌برگشت نیست' } };

    const available = product.stock - custodyOutstandingQty(product.id);
    if (qty > available) {
      return { status: 400, body: { error: `موجودی قابل تحویل کافی نیست. موجودی: ${product.stock}، در گردش: ${custodyOutstandingQty(product.id)}، قابل تحویل: ${available}` } };
    }

    const docNumber = nextDocNumber('custIssue');
    const now = new Date().toISOString();
    const result = db.prepare(`INSERT INTO custody_records (doc_number, product_id, quantity, issue_date, holder, unit, expected_return, condition_out, notes, status, created_by_user_id, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'باز', ?, ?)`)
      .run(docNumber, product.id, qty, date, String(holder).trim(), unit, expectedReturn || null, conditionOut || 'سالم', notes || null, ctx.user.id, now);

    const row = db.prepare('SELECT * FROM custody_records WHERE id = ?').get(Number(result.lastInsertRowid));
    return { status: 201, body: { custodyRecord: serializeCustody(row) } };
  }
});

routes.push({
  method: 'POST', path: '/api/custody/:id/return', permission: 'custody.manage',
  handler: (ctx) => {
    const id = Number(ctx.params.id);
    const record = db.prepare('SELECT * FROM custody_records WHERE id = ?').get(id);
    if (!record) return { status: 404, body: { error: 'رکورد امانت یافت نشد' } };
    if (record.status !== 'باز') return { status: 400, body: { error: 'این رکورد قبلاً تسویه شده است' } };

    const { date, conditionIn, notes } = ctx.body || {};
    if (!date) return { status: 400, body: { error: 'تاریخ بازگشت الزامی است' } };
    if (!conditionIn) return { status: 400, body: { error: 'وضعیت بازگشت الزامی است' } };
    if ((conditionIn === 'آسیب‌دیده' || conditionIn === 'مفقود') && (!notes || !String(notes).trim())) {
      return { status: 400, body: { error: 'برای وضعیت آسیب‌دیده یا مفقود، ثبت توضیحات الزامی است' } };
    }

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(record.product_id);
    const returnDocNumber = nextDocNumber('custReturn');
    const now = new Date().toISOString();

    db.prepare(`UPDATE custody_records SET status = 'بسته', return_date = ?, condition_in = ?, return_notes = ?, return_doc_number = ? WHERE id = ?`)
      .run(date, conditionIn, notes || null, returnDocNumber, id);

    let extra = {};

    if (conditionIn === 'مفقود' && product) {
      const newStock = Math.max(0, product.stock - record.quantity);
      db.prepare('UPDATE products SET stock = ?, updated_at = ? WHERE id = ?').run(newStock, now, product.id);
      const outDoc = nextDocNumber('out');
      db.prepare(`INSERT INTO transactions (doc_number, product_id, type, quantity, date, requesting_unit, receiver, reason, description, created_by_user_id, created_at)
                  VALUES (?, ?, 'خروج', ?, ?, ?, ?, 'ضایعات', ?, ?, ?)`)
        .run(outDoc, product.id, record.quantity, date, record.unit, record.holder,
          `کسر موجودی به دلیل مفقودی ابزار امانی (سند امانت مرجع: ${record.doc_number})`, ctx.user.id, now);
      extra.stockAdjusted = true;
    } else if (conditionIn === 'نیازمند تعمیر') {
      const repDoc = nextDocNumber('repIn');
      db.prepare(`INSERT INTO repair_records (doc_number, product_id, quantity, send_date, submitted_by, repair_shop, issue_description, status, source_custody_id, created_by_user_id, created_at)
                  VALUES (?, ?, ?, ?, ?, 'کارگاه تعمیرات داخلی', ?, 'در حال تعمیر', ?, ?, ?)`)
        .run(repDoc, record.product_id, record.quantity, date, record.holder,
          `ایجاد خودکار پس از بازگشت از امانت (سند امانت: ${record.doc_number}). شرح: ${notes || ''}`,
          record.id, ctx.user.id, now);
      extra.repairDocNumber = repDoc;
    }

    const row = db.prepare('SELECT * FROM custody_records WHERE id = ?').get(id);
    return { status: 200, body: { custodyRecord: serializeCustody(row), ...extra } };
  }
});

module.exports = routes;
