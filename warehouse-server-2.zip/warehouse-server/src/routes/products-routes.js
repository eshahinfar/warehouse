'use strict';

const { db } = require('../db');
const { nextDocNumber, getStockStatus, addAuditEntry, isoToday } = require('../business');

const routes = [];

function serializeProduct(row) {
  return {
    id: row.id, code: row.code, name: row.name, type: row.type, unit: row.unit,
    stock: row.stock, minStock: row.min_stock, usageLocation: row.usage_location,
    shelf: row.shelf, description: row.description,
    status: getStockStatus(row)
  };
}

routes.push({
  method: 'GET', path: '/api/products', permission: 'products.view',
  handler: () => {
    const rows = db.prepare('SELECT * FROM products ORDER BY id DESC').all();
    return { status: 200, body: { products: rows.map(serializeProduct) } };
  }
});

routes.push({
  method: 'GET', path: '/api/products/usage-locations', permission: 'products.view',
  handler: () => {
    const rows = db.prepare("SELECT DISTINCT usage_location FROM products WHERE usage_location IS NOT NULL AND usage_location != ''").all();
    return { status: 200, body: { usageLocations: rows.map(r => r.usage_location) } };
  }
});

routes.push({
  method: 'POST', path: '/api/products', permission: 'products.edit',
  handler: (ctx) => {
    const { code, name, type, unit, minStock, openingStock, usageLocation, shelf, description } = ctx.body || {};

    if (!code || !String(code).trim()) return { status: 400, body: { error: 'کد کالا الزامی است' } };
    if (!name || !String(name).trim()) return { status: 400, body: { error: 'نام کالا الزامی است' } };
    if (!unit) return { status: 400, body: { error: 'واحد اندازه‌گیری الزامی است' } };
    const minStockNum = Number(minStock);
    if (isNaN(minStockNum) || minStockNum < 0) return { status: 400, body: { error: 'حداقل موجودی نامعتبر است' } };

    const existing = db.prepare('SELECT id FROM products WHERE code = ?').get(String(code).trim());
    if (existing) return { status: 409, body: { error: 'این کد کالا قبلاً ثبت شده است' } };

    const now = new Date().toISOString();
    const openingStockNum = Math.max(0, Number(openingStock) || 0);
    const productType = type === 'قابل‌برگشت' ? 'قابل‌برگشت' : 'مصرفی';

    const result = db.prepare(`INSERT INTO products (code, name, type, unit, stock, min_stock, usage_location, shelf, description, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(String(code).trim(), String(name).trim(), productType, unit, openingStockNum, minStockNum,
        usageLocation || null, shelf || null, description || null, now, now);

    const productId = Number(result.lastInsertRowid);

    if (openingStockNum > 0) {
      const docNumber = nextDocNumber('in');
      db.prepare(`INSERT INTO transactions (doc_number, product_id, type, quantity, date, source, description, created_by_user_id, created_at)
                  VALUES (?, ?, 'ورود', ?, ?, '-', 'موجودی اولیه هنگام تعریف کالا', ?, ?)`)
        .run(docNumber, productId, openingStockNum, isoToday(), ctx.user.id, now);
    }

    const row = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);
    return { status: 201, body: { product: serializeProduct(row) } };
  }
});

routes.push({
  method: 'PUT', path: '/api/products/:id', permission: 'products.edit',
  handler: (ctx) => {
    const id = Number(ctx.params.id);
    const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
    if (!existing) return { status: 404, body: { error: 'کالا یافت نشد' } };

    const { code, name, type, unit, minStock, usageLocation, shelf, description } = ctx.body || {};
    if (!code || !String(code).trim()) return { status: 400, body: { error: 'کد کالا الزامی است' } };
    if (!name || !String(name).trim()) return { status: 400, body: { error: 'نام کالا الزامی است' } };
    if (!unit) return { status: 400, body: { error: 'واحد اندازه‌گیری الزامی است' } };
    const minStockNum = Number(minStock);
    if (isNaN(minStockNum) || minStockNum < 0) return { status: 400, body: { error: 'حداقل موجودی نامعتبر است' } };

    const duplicate = db.prepare('SELECT id FROM products WHERE code = ? AND id != ?').get(String(code).trim(), id);
    if (duplicate) return { status: 409, body: { error: 'این کد کالا قبلاً برای کالای دیگری ثبت شده است' } };

    const productType = type === 'قابل‌برگشت' ? 'قابل‌برگشت' : 'مصرفی';
    db.prepare(`UPDATE products SET code = ?, name = ?, type = ?, unit = ?, min_stock = ?, usage_location = ?, shelf = ?, description = ?, updated_at = ?
                WHERE id = ?`)
      .run(String(code).trim(), String(name).trim(), productType, unit, minStockNum, usageLocation || null, shelf || null, description || null, new Date().toISOString(), id);

    const row = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
    return { status: 200, body: { product: serializeProduct(row) } };
  }
});

// حذف کالا: فقط مدیر سیستم (permission غیرقابل‌واگذاری به نقش‌های دیگر)
// و نیازمند ثبت دلیل — دقیقاً مطابق همان کنترل ضدسوءاستفاده‌ی نسخه آفلاین،
// با این تفاوت که این‌جا به‌جای رمز مشترک، هویت واقعی کاربرِ واردشده در
// لاگ حسابرسی ثبت می‌شود.
routes.push({
  method: 'DELETE', path: '/api/products/:id', permission: 'products.delete',
  handler: (ctx) => {
    const id = Number(ctx.params.id);
    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
    if (!product) return { status: 404, body: { error: 'کالا یافت نشد' } };

    const { reason } = ctx.body || {};
    if (!reason || !String(reason).trim()) {
      return { status: 400, body: { error: 'ثبت دلیل حذف الزامی است' } };
    }

    const txCount = db.prepare('SELECT COUNT(*) AS c FROM transactions WHERE product_id = ?').get(id).c;

    db.prepare('DELETE FROM transactions WHERE product_id = ?').run(id);
    db.prepare('DELETE FROM requests WHERE product_id = ?').run(id);
    db.prepare('DELETE FROM custody_records WHERE product_id = ?').run(id);
    db.prepare('DELETE FROM repair_records WHERE product_id = ?').run(id);
    db.prepare('DELETE FROM products WHERE id = ?').run(id);

    addAuditEntry({
      action: 'حذف کالا',
      docNumber: product.code,
      changeDescription: `کالای «${product.name}» (${product.code}) به همراه ${txCount} سند تراکنش مرتبط حذف شد.`,
      reason: String(reason).trim(),
      userId: ctx.user.id
    });

    return { status: 200, body: { ok: true } };
  }
});

module.exports = routes;
