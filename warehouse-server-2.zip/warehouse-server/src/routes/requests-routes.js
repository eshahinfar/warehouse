'use strict';

const { db } = require('../db');
const { nextDocNumber, renumberRequests, getStockStatus, isoToday } = require('../business');

const routes = [];

function serializeRequest(row) {
  return {
    id: row.id, docNumber: row.doc_number, productId: row.product_id, quantity: row.quantity,
    date: row.date, priority: row.priority, status: row.status, notes: row.notes, auto: !!row.auto
  };
}

routes.push({
  method: 'GET', path: '/api/requests', permission: 'requests.view',
  handler: (ctx) => {
    const { search } = ctx.query || {};
    let rows = db.prepare('SELECT * FROM requests ORDER BY id DESC').all();
    if (search) {
      const q = String(search).toLowerCase();
      const productsById = {};
      db.prepare('SELECT id, name, code FROM products').all().forEach(p => { productsById[p.id] = p; });
      rows = rows.filter(r => {
        const p = productsById[r.product_id];
        return (r.doc_number || '').toLowerCase().includes(q) ||
          (p && p.name.toLowerCase().includes(q)) || (p && p.code.toLowerCase().includes(q));
      });
    }
    return { status: 200, body: { requests: rows.map(serializeRequest) } };
  }
});

routes.push({
  method: 'POST', path: '/api/requests', permission: 'requests.create',
  handler: (ctx) => {
    const { productId, quantity, date, priority, notes } = ctx.body || {};
    const qty = Number(quantity);
    if (!productId) return { status: 400, body: { error: 'انتخاب کالا الزامی است' } };
    if (isNaN(qty) || qty <= 0) return { status: 400, body: { error: 'تعداد باید عددی بزرگ‌تر از صفر باشد' } };
    if (!date) return { status: 400, body: { error: 'تاریخ الزامی است' } };

    const product = db.prepare('SELECT id FROM products WHERE id = ?').get(Number(productId));
    if (!product) return { status: 404, body: { error: 'کالای انتخاب‌شده معتبر نیست' } };

    const docNumber = nextDocNumber('req');
    const now = new Date().toISOString();
    const result = db.prepare(`INSERT INTO requests (doc_number, product_id, quantity, date, priority, status, notes, auto, created_by_user_id, created_at)
                VALUES (?, ?, ?, ?, ?, 'در انتظار', ?, 0, ?, ?)`)
      .run(docNumber, Number(productId), qty, date, priority || 'عادی', notes || null, ctx.user.id, now);

    const row = db.prepare('SELECT * FROM requests WHERE id = ?').get(Number(result.lastInsertRowid));
    return { status: 201, body: { request: serializeRequest(row) } };
  }
});

routes.push({
  method: 'PUT', path: '/api/requests/:id', permission: 'requests.manage',
  handler: (ctx) => {
    const id = Number(ctx.params.id);
    const existing = db.prepare('SELECT * FROM requests WHERE id = ?').get(id);
    if (!existing) return { status: 404, body: { error: 'درخواست یافت نشد' } };
    if (existing.status !== 'در انتظار') return { status: 400, body: { error: 'فقط درخواست‌های «در انتظار» قابل ویرایش هستند' } };

    const { productId, quantity, date, priority, notes } = ctx.body || {};
    const qty = Number(quantity);
    if (!productId) return { status: 400, body: { error: 'انتخاب کالا الزامی است' } };
    if (isNaN(qty) || qty <= 0) return { status: 400, body: { error: 'تعداد باید عددی بزرگ‌تر از صفر باشد' } };
    if (!date) return { status: 400, body: { error: 'تاریخ الزامی است' } };

    db.prepare('UPDATE requests SET product_id = ?, quantity = ?, date = ?, priority = ?, notes = ? WHERE id = ?')
      .run(Number(productId), qty, date, priority || 'عادی', notes || null, id);

    const row = db.prepare('SELECT * FROM requests WHERE id = ?').get(id);
    return { status: 200, body: { request: serializeRequest(row) } };
  }
});

routes.push({
  method: 'POST', path: '/api/requests/:id/cancel', permission: 'requests.manage',
  handler: (ctx) => {
    const id = Number(ctx.params.id);
    const existing = db.prepare('SELECT * FROM requests WHERE id = ?').get(id);
    if (!existing) return { status: 404, body: { error: 'درخواست یافت نشد' } };
    db.prepare("UPDATE requests SET status = 'لغو شده' WHERE id = ?").run(id);
    return { status: 200, body: { ok: true } };
  }
});

routes.push({
  method: 'DELETE', path: '/api/requests/:id', permission: 'requests.manage',
  handler: (ctx) => {
    const id = Number(ctx.params.id);
    const existing = db.prepare('SELECT * FROM requests WHERE id = ?').get(id);
    if (!existing) return { status: 404, body: { error: 'درخواست یافت نشد' } };
    db.prepare('DELETE FROM requests WHERE id = ?').run(id);
    renumberRequests();
    return { status: 200, body: { ok: true } };
  }
});

routes.push({
  method: 'POST', path: '/api/requests/auto-generate', permission: 'requests.manage',
  handler: () => {
    const products = db.prepare('SELECT * FROM products').all();
    const lowStock = products.filter(p => p.stock < p.min_stock);
    let count = 0;

    lowStock.forEach(product => {
      const existingOpen = db.prepare("SELECT id FROM requests WHERE product_id = ? AND status = 'در انتظار'").get(product.id);
      if (existingOpen) return;

      const requiredQty = Math.max(product.min_stock * 2 - product.stock, 1);
      const docNumber = nextDocNumber('req');
      const now = new Date().toISOString();
      db.prepare(`INSERT INTO requests (doc_number, product_id, quantity, date, priority, status, notes, auto, created_at)
                  VALUES (?, ?, ?, ?, 'بحرانی', 'در انتظار', 'تولید خودکار — موجودی زیر حداقل تعیین‌شده', 1, ?)`)
        .run(docNumber, product.id, requiredQty, isoToday(), now);
      count++;
    });

    return { status: 200, body: { createdCount: count } };
  }
});

module.exports = routes;
