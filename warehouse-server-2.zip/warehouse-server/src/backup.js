'use strict';
/* ======================================================================
   پشتیبان‌گیری خودکار زمان‌بندی‌شده از پایگاه‌داده

   چون تمام داده‌ها در یک فایل SQLite است (data/warehouse.db)، ساده‌ترین و
   قابل‌اعتمادترین روش پشتیبان‌گیری، کپی همان فایل در فواصل زمانی مشخص
   است. برای اینکه کپی وسط یک نوشتن هم‌زمان خراب نشود، از دستور استاندارد
   SQLite «VACUUM INTO» استفاده می‌شود که یک نسخه‌ی سازگار و کامل از
   پایگاه‌داده در لحظه‌ی درخواست می‌سازد (safe hot backup).
   ====================================================================== */

const fs = require('node:fs');
const path = require('node:path');
const { db, DB_PATH } = require('./db');
const config = require('./config');

function formatTimestampForFilename(date) {
  const pad = n => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}_${pad(date.getHours())}-${pad(date.getMinutes())}`;
}

function performBackup() {
  try {
    if (!fs.existsSync(config.backup.dir)) {
      fs.mkdirSync(config.backup.dir, { recursive: true });
    }
    const filename = `warehouse-backup_${formatTimestampForFilename(new Date())}.db`;
    const destPath = path.join(config.backup.dir, filename);

    // VACUUM INTO می‌نویسد یک کپی سازگار و فشرده از پایگاه‌داده در مسیر
    // مقصد، بدون قفل کردن دیتابیس اصلی برای کاربران دیگر.
    db.exec(`VACUUM INTO '${destPath.replace(/'/g, "''")}'`);

    console.log(`[پشتیبان‌گیری] نسخه پشتیبان جدید ذخیره شد: ${filename}`);
    cleanupOldBackups();
  } catch (e) {
    console.error('[پشتیبان‌گیری] خطا در ساخت نسخه پشتیبان:', e.message);
  }
}

function cleanupOldBackups() {
  try {
    const files = fs.readdirSync(config.backup.dir)
      .filter(f => f.startsWith('warehouse-backup_') && f.endsWith('.db'))
      .map(f => ({ name: f, mtime: fs.statSync(path.join(config.backup.dir, f)).mtimeMs }))
      .sort((a, b) => b.mtime - a.mtime);

    const toDelete = files.slice(config.backup.keepCount);
    toDelete.forEach(f => {
      fs.unlinkSync(path.join(config.backup.dir, f.name));
      console.log(`[پشتیبان‌گیری] نسخه قدیمی حذف شد: ${f.name}`);
    });
  } catch (e) {
    console.error('[پشتیبان‌گیری] خطا در پاک‌سازی نسخه‌های قدیمی:', e.message);
  }
}

function startScheduledBackups() {
  if (!config.backup.enabled) {
    console.log('[پشتیبان‌گیری] پشتیبان‌گیری خودکار غیرفعال است (backupEnabled=false)');
    return;
  }
  const intervalMs = config.backup.intervalHours * 60 * 60 * 1000;
  console.log(`[پشتیبان‌گیری] پشتیبان‌گیری خودکار هر ${config.backup.intervalHours} ساعت فعال شد (مسیر: ${config.backup.dir})`);

  // یک نسخه هم بلافاصله در شروع سرور گرفته می‌شود
  performBackup();
  setInterval(performBackup, intervalMs);
}

module.exports = { startScheduledBackups, performBackup };
