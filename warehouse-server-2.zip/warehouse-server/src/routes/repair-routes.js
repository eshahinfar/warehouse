'use strict';

const { db } = require('../db');
const { nextDocNumber } = require('../business');

const routes = [];

function serializeRepair(row) {
  return {
    id: row.id, docNumber: row.doc_number, productId: row.product_id, quantity: row.quantity,
    sendDate: row.send_date, submittedBy: row.submitted_by, repairShop: row.repair_shop,
    issueDescription: row.issue_description, status: row.status, resultDate: row.result_date,
    result: row.result, technician: row.technician, approver: row.approver,
    resultNotes: row.result_notes, resultDocNumber: row.result_doc_number
  };
}

routes.push({
  method: 'GET', path: '/api/repair', permission: 'repair.manage',
  handler: () => {
    const rows = db.prepare('SELECT * FROM repair_records ORDER BY id DESC').all();
    return { status: 200, body: { repairRecords: rows.map(serializeRepair) } };
  }
});

routes.push({
  method: 'POST', path: '/api/repair/send', permission: 'repair.manage',
  handler: (ctx) => {
    const { productId, quantity, date, submittedBy, repairShop, issueDescription } = ctx.body || {};
    const qty = Number(quantity);
    if (!productId) return { status: 400, body: { error: 'انتخاب کالا الزامی است' } };
    if (isNaN(qty) || qty <= 0) return { status: 400, body: { error: 'تعداد باید عددی بزرگ‌تر از صفر باشد' } };
    if (!date) return { status: 400, body: { error: 'تاریخ ارسال الزامی است' } };
    if (!submittedBy || !String(submittedBy).trim()) return { status: 400, body: { error: 'نام تحویل‌دهنده الزامی است' } };
    if (!issueDescription || !String(issueDescription).trim()) return { status: 400, body: { error: 'شرح خرابی الزامی است' } };

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(Number(productId));
    if (!product) return { status: 404, body: { error: 'کالای انتخاب‌شده معتبر نیست' } };

    const docNumber = nextDocNumber('repIn');
    const now = new Date().toISOString();
    const result = db.prepare(`INSERT INTO repair_records (doc_number, product_id, quantity, send_date, submitted_by, repair_shop, issue_description, status, created_by_user_id, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'در حال تعمیر', ?, ?)`)
      .run(docNumber, product.id, qty, date, String(submittedBy).trim(), repairShop || 'کارگاه تعمیرات داخلی', String(issueDescription).trim(), ctx.user.id, now);

    const row = db.prepare('SELECT * FROM repair_records WHERE id = ?').get(Number(result.lastInsertRowid));
    return { status: 201, body: { repairRecord: serializeRepair(row) } };
  }
});

routes.push({
  method: 'POST', path: '/api/repair/:id/complete', permission: 'repair.manage',
  handler: (ctx) => {
    const id = Number(ctx.params.id);
    const record = db.prepare('SELECT * FROM repair_records WHERE id = ?').get(id);
    if (!record) return { status: 404, body: { error: 'رکورد تعمیر یافت نشد' } };
    if (record.status !== 'در حال تعمیر') return { status: 400, body: { error: 'این رکورد قبلاً تکمیل شده است' } };

    const { date, result, technician, approver, resultNotes } = ctx.body || {};
    if (!date) return { status: 400, body: { error: 'تاریخ تکمیل الزامی است' } };
    if (!result) return { status: 400, body: { error: 'نتیجه تعمیر الزامی است' } };
    if (!approver || !String(approver).trim()) return { status: 400, body: { error: 'ثبت نام تأییدکننده تعمیرات الزامی است' } };

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(record.product_id);
    const resultDocNumber = nextDocNumber('repOut');
    const newStatus = result === 'نیاز به قطعه یدکی' ? 'در حال تعمیر' : 'تکمیل شده';
    const now = new Date().toISOString();

    db.prepare(`UPDATE repair_records SET status = ?, result_date = ?, result = ?, technician = ?, approver = ?, result_notes = ?, result_doc_number = ? WHERE id = ?`)
      .run(newStatus, date, result, technician || null, String(approver).trim(), resultNotes || null, resultDocNumber, id);

    let stockAdjusted = false;
    if (result === 'غیرقابل تعمیر - اسقاط' && product) {
      const newStock = Math.max(0, product.stock - record.quantity);
      db.prepare('UPDATE products SET stock = ?, updated_at = ? WHERE id = ?').run(newStock, now, product.id);
      const outDoc = nextDocNumber('out');
      db.prepare(`INSERT INTO transactions (doc_number, product_id, type, quantity, date, requesting_unit, receiver, reason, description, created_by_user_id, created_at)
                  VALUES (?, ?, 'خروج', ?, ?, 'تعمیر و نگهداری', ?, 'ضایعات', ?, ?, ?)`)
        .run(outDoc, product.id, record.quantity, date, record.submitted_by,
          `کسر موجودی به دلیل اسقاط پس از تعمیر ناموفق (سند تعمیر مرجع: ${record.doc_number})`, ctx.user.id, now);
      stockAdjusted = true;
    }

    const row = db.prepare('SELECT * FROM repair_records WHERE id = ?').get(id);
    return { status: 200, body: { repairRecord: serializeRepair(row), stockAdjusted } };
  }
});

module.exports = routes;
