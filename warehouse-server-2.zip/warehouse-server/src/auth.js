'use strict';
/* ======================================================================
   احراز هویت، نشست‌ها (Sessions)، و کنترل سطح دسترسی (Roles)
   رمزنگاری با scrypt (ماژول داخلی node:crypto) — بدون bcrypt یا هر
   بسته خارجی دیگر.
   ====================================================================== */

const crypto = require('node:crypto');
const { db } = require('./db');

const SESSION_DURATION_MS = 12 * 60 * 60 * 1000; // 12 ساعت
const SCRYPT_KEYLEN = 64;

// ---------------------------------------------------------------------
// Roles: each role's allowed permission keys. Server routes check these
// — this is the actual enforcement layer; the frontend UI hiding is only
// a convenience, never the security boundary.
// ---------------------------------------------------------------------
const ROLES = {
  'مدیر سیستم': {
    label: 'مدیر سیستم',
    permissions: ['*'] // همه‌چیز
  },
  'انباردار': {
    label: 'انباردار',
    permissions: [
      'products.view', 'products.edit',
      'stock.in', 'stock.out', 'returns.create',
      'custody.manage', 'repair.manage',
      'requests.view', 'requests.create', 'requests.manage', 'requests.fulfill',
      'reports.view', 'dashboard.view'
    ]
  },
  'درخواست‌دهنده': {
    label: 'درخواست‌دهنده',
    permissions: [
      'products.view', 'requests.view', 'requests.create',
      'dashboard.view'
    ]
  },
  'ناظر': {
    label: 'ناظر (فقط مشاهده)',
    permissions: [
      'products.view', 'requests.view', 'reports.view', 'dashboard.view'
    ]
  }
};

function roleHasPermission(role, permission) {
  const def = ROLES[role];
  if (!def) return false;
  if (def.permissions.includes('*')) return true;
  return def.permissions.includes(permission);
}

// ---------------------------------------------------------------------
// Password hashing (scrypt + random salt, both stored per-user)
// ---------------------------------------------------------------------
function hashPassword(plainPassword, saltHex) {
  const salt = saltHex ? Buffer.from(saltHex, 'hex') : crypto.randomBytes(16);
  const hash = crypto.scryptSync(plainPassword, salt, SCRYPT_KEYLEN);
  return { hash: hash.toString('hex'), salt: salt.toString('hex') };
}

function verifyPassword(plainPassword, storedHashHex, storedSaltHex) {
  const { hash } = hashPassword(plainPassword, storedSaltHex);
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(storedHashHex, 'hex');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

// ---------------------------------------------------------------------
// Sessions
// ---------------------------------------------------------------------
function createSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  const now = new Date();
  const expires = new Date(now.getTime() + SESSION_DURATION_MS);
  db.prepare('INSERT INTO sessions (token, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)')
    .run(token, userId, now.toISOString(), expires.toISOString());
  return token;
}

function getSessionUser(token) {
  if (!token) return null;
  const session = db.prepare('SELECT * FROM sessions WHERE token = ?').get(token);
  if (!session) return null;
  if (new Date(session.expires_at) < new Date()) {
    db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
    return null;
  }
  const user = db.prepare('SELECT id, username, full_name, role, active, must_change_password FROM users WHERE id = ?').get(session.user_id);
  if (!user || !user.active) return null;
  return user;
}

function destroySession(token) {
  db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
}

function cleanupExpiredSessions() {
  db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(new Date().toISOString());
}

// ---------------------------------------------------------------------
// Bootstrap: create a default administrator account on first run so the
// facility always has a way in. Credentials are printed to the server
// console once; the admin should change the password immediately from
// the "کاربران" screen.
// ---------------------------------------------------------------------
function ensureDefaultAdmin() {
  const existing = db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'مدیر سیستم'").get();
  if (existing.c > 0) return;

  const defaultUsername = 'admin';
  const defaultPassword = '111111';
  const { hash, salt } = hashPassword(defaultPassword);
  db.prepare(`INSERT INTO users (username, password_hash, password_salt, full_name, role, active, created_at, must_change_password)
              VALUES (?, ?, ?, ?, ?, 1, ?, 1)`)
    .run(defaultUsername, hash, salt, 'مدیر سیستم', 'مدیر سیستم', new Date().toISOString());

  console.log('----------------------------------------------------------');
  console.log(' حساب مدیر پیش‌فرض ایجاد شد:');
  console.log('   نام کاربری : admin');
  console.log('   رمز عبور   : 111111');
  console.log(' لطفاً بلافاصله پس از اولین ورود، این رمز را تغییر دهید.');
  console.log('----------------------------------------------------------');
}

module.exports = {
  ROLES,
  roleHasPermission,
  hashPassword,
  verifyPassword,
  createSession,
  getSessionUser,
  destroySession,
  cleanupExpiredSessions,
  ensureDefaultAdmin
};
