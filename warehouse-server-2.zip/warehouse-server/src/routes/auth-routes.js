'use strict';

const { db } = require('../db');
const { hashPassword, verifyPassword, createSession, destroySession, ROLES } = require('../auth');

const routes = [];

routes.push({
  method: 'POST', path: '/api/login', permission: null,
  handler: (ctx) => {
    const { username, password } = ctx.body || {};
    if (!username || !password) {
      return { status: 400, body: { error: 'نام کاربری و رمز عبور الزامی است' } };
    }
    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(String(username).trim());
    if (!user || !user.active) {
      return { status: 401, body: { error: 'نام کاربری یا رمز عبور اشتباه است' } };
    }
    if (!verifyPassword(password, user.password_hash, user.password_salt)) {
      return { status: 401, body: { error: 'نام کاربری یا رمز عبور اشتباه است' } };
    }
    const token = createSession(user.id);
    return {
      status: 200,
      setSessionToken: token,
      body: {
        user: {
          id: user.id, username: user.username, fullName: user.full_name,
          role: user.role, mustChangePassword: !!user.must_change_password
        },
        permissions: ROLES[user.role] ? ROLES[user.role].permissions : []
      }
    };
  }
});

routes.push({
  method: 'POST', path: '/api/logout', permission: 'authenticated',
  handler: (ctx) => {
    if (ctx.sessionToken) destroySession(ctx.sessionToken);
    return { status: 200, clearSessionToken: true, body: { ok: true } };
  }
});

routes.push({
  method: 'GET', path: '/api/me', permission: 'authenticated',
  handler: (ctx) => {
    const role = ctx.user.role;
    return {
      status: 200,
      body: {
        user: {
          id: ctx.user.id, username: ctx.user.username, fullName: ctx.user.full_name,
          role, mustChangePassword: !!ctx.user.must_change_password
        },
        permissions: ROLES[role] ? ROLES[role].permissions : [],
        roles: Object.keys(ROLES).map(r => ({ key: r, label: ROLES[r].label }))
      }
    };
  }
});

routes.push({
  method: 'PUT', path: '/api/me/password', permission: 'authenticated',
  handler: (ctx) => {
    const { currentPassword, newPassword } = ctx.body || {};
    if (!newPassword || String(newPassword).length < 4) {
      return { status: 400, body: { error: 'رمز جدید باید حداقل ۴ کاراکتر باشد' } };
    }
    const fullUser = db.prepare('SELECT * FROM users WHERE id = ?').get(ctx.user.id);
    if (!verifyPassword(currentPassword || '', fullUser.password_hash, fullUser.password_salt)) {
      return { status: 401, body: { error: 'رمز فعلی اشتباه است' } };
    }
    const { hash, salt } = hashPassword(newPassword);
    db.prepare('UPDATE users SET password_hash = ?, password_salt = ?, must_change_password = 0 WHERE id = ?')
      .run(hash, salt, ctx.user.id);
    return { status: 200, body: { ok: true } };
  }
});

// ---------------------------------------------------------------------
// User management (admin only — enforced via '*' permission requirement)
// ---------------------------------------------------------------------
routes.push({
  method: 'GET', path: '/api/users', permission: 'users.manage',
  handler: () => {
    const users = db.prepare('SELECT id, username, full_name, role, active, must_change_password, created_at FROM users ORDER BY id ASC').all();
    return { status: 200, body: { users } };
  }
});

routes.push({
  method: 'POST', path: '/api/users', permission: 'users.manage',
  handler: (ctx) => {
    const { username, password, fullName, role } = ctx.body || {};
    if (!username || !password || !fullName || !role) {
      return { status: 400, body: { error: 'همه فیلدها الزامی هستند' } };
    }
    if (!ROLES[role]) {
      return { status: 400, body: { error: 'نقش انتخاب‌شده معتبر نیست' } };
    }
    const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(String(username).trim());
    if (existing) {
      return { status: 409, body: { error: 'این نام کاربری قبلاً استفاده شده است' } };
    }
    const { hash, salt } = hashPassword(password);
    const result = db.prepare(`INSERT INTO users (username, password_hash, password_salt, full_name, role, active, created_at, must_change_password)
                VALUES (?, ?, ?, ?, ?, 1, ?, 1)`)
      .run(String(username).trim(), hash, salt, fullName, role, new Date().toISOString());
    return { status: 201, body: { id: Number(result.lastInsertRowid) } };
  }
});

routes.push({
  method: 'PUT', path: '/api/users/:id', permission: 'users.manage',
  handler: (ctx) => {
    const id = Number(ctx.params.id);
    const target = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
    if (!target) return { status: 404, body: { error: 'کاربر یافت نشد' } };

    const { fullName, role, active, newPassword } = ctx.body || {};
    if (role && !ROLES[role]) return { status: 400, body: { error: 'نقش معتبر نیست' } };
    if (target.role === 'مدیر سیستم' && role && role !== 'مدیر سیستم') {
      const otherAdmins = db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'مدیر سیستم' AND id != ?").get(id);
      if (otherAdmins.c === 0) {
        return { status: 400, body: { error: 'حداقل یک مدیر سیستم باید در سامانه باقی بماند' } };
      }
    }
    if (target.role === 'مدیر سیستم' && active === false) {
      const otherActiveAdmins = db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'مدیر سیستم' AND active = 1 AND id != ?").get(id);
      if (otherActiveAdmins.c === 0) {
        return { status: 400, body: { error: 'حداقل یک مدیر سیستم فعال باید در سامانه باقی بماند' } };
      }
    }

    db.prepare(`UPDATE users SET full_name = COALESCE(?, full_name), role = COALESCE(?, role), active = COALESCE(?, active) WHERE id = ?`)
      .run(fullName ?? null, role ?? null, active === undefined ? null : (active ? 1 : 0), id);

    if (newPassword) {
      if (String(newPassword).length < 4) return { status: 400, body: { error: 'رمز جدید باید حداقل ۴ کاراکتر باشد' } };
      const { hash, salt } = hashPassword(newPassword);
      db.prepare('UPDATE users SET password_hash = ?, password_salt = ?, must_change_password = 1 WHERE id = ?').run(hash, salt, id);
    }

    return { status: 200, body: { ok: true } };
  }
});

module.exports = routes;
