'use strict';

const { db } = require('../db');
const { getStockStatus } = require('../business');

const routes = [];

function serializeProduct(row) {
  return {
    id: row.id, code: row.code, name: row.name, type: row.type, unit: row.unit,
    stock: row.stock, minStock: row.min_stock, usageLocation: row.usage_location,
    shelf: row.shelf, description: row.description, status: getStockStatus(row)
  };
}

routes.push({
  method: 'GET', path: '/api/reports/shortage', permission: 'reports.view',
  handler: (ctx) => {
    const level = (ctx.query && ctx.query.level) || 'both';
    const products = db.prepare('SELECT * FROM products').all();
    const critical = products.filter(p => getStockStatus(p) === 'critical').map(serializeProduct);
    const warn = products.filter(p => getStockStatus(p) === 'warn').map(serializeProduct);

    const body = {};
    if (level === 'critical' || level === 'both') body.critical = critical;
    if (level === 'warn' || level === 'both') body.warn = warn;
    return { status: 200, body };
  }
});

routes.push({
  method: 'GET', path: '/api/reports/kardex', permission: 'reports.view',
  handler: (ctx) => {
    const { productId, startDate, endDate } = ctx.query || {};
    if (!productId) return { status: 400, body: { error: 'شناسه کالا الزامی است' } };

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(Number(productId));
    if (!product) return { status: 404, body: { error: 'کالا یافت نشد' } };

    const allTx = db.prepare('SELECT * FROM transactions WHERE product_id = ? ORDER BY date ASC, id ASC').all(Number(productId));

    let running = 0;
    const withBalance = allTx.map(t => {
      running += (t.type === 'خروج' ? -t.quantity : t.quantity);
      return {
        id: t.id, docNumber: t.doc_number, type: t.type, quantity: t.quantity, date: t.date,
        counterparty: t.type === 'ورود' ? t.source : t.type === 'مرجوعی' ? t.returned_by : t.receiver,
        description: t.description, balance: running
      };
    });

    let filtered = withBalance;
    if (startDate) filtered = filtered.filter(t => t.date >= startDate);
    if (endDate) filtered = filtered.filter(t => t.date <= endDate);

    return {
      status: 200,
      body: { product: serializeProduct(product), entries: filtered }
    };
  }
});

routes.push({
  method: 'GET', path: '/api/reports/custom', permission: 'reports.view',
  handler: (ctx) => {
    const { startDate, endDate, receiver, requestingUnit, usageLocation, type } = ctx.query || {};

    let sql = 'SELECT * FROM transactions WHERE 1=1';
    const args = [];
    if (startDate) { sql += ' AND date >= ?'; args.push(startDate); }
    if (endDate) { sql += ' AND date <= ?'; args.push(endDate); }
    if (requestingUnit) { sql += ' AND requesting_unit = ?'; args.push(requestingUnit); }
    if (type && type !== 'all') { sql += ' AND type = ?'; args.push(type); }
    sql += ' ORDER BY id DESC';

    let rows = db.prepare(sql).all(...args);

    if (receiver) {
      const q = String(receiver).toLowerCase();
      rows = rows.filter(t => (t.receiver || '').toLowerCase().includes(q) || (t.returned_by || '').toLowerCase().includes(q));
    }

    const productsById = {};
    db.prepare('SELECT * FROM products').all().forEach(p => { productsById[p.id] = p; });

    if (usageLocation) {
      rows = rows.filter(t => {
        const p = productsById[t.product_id];
        return p && p.usage_location === usageLocation;
      });
    }

    const results = rows.map(t => {
      const p = productsById[t.product_id];
      return {
        docNumber: t.doc_number, date: t.date, productName: p ? p.name : null, type: t.type,
        quantity: t.quantity, requestingUnit: t.requesting_unit,
        party: t.receiver || t.returned_by || t.source || null,
        usageLocation: p ? p.usage_location : null
      };
    });

    return { status: 200, body: { results } };
  }
});

module.exports = routes;
